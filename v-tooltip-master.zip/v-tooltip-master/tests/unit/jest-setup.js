import '@babel/polyfill'

global.SVGAnimatedString = () => {}
global.SVGElement = () => {}
