# Contributing Guidelines

(WIP)

## Run the project

Install deps:

```
yarn
```

Run the tests:

```
yarn run test:unit --watch
```

Build the library in dev mode:

```
yarn run dev
```

Build the library for production:

```
yarn run build
```

### Demo

Run the demo:

```
cd demo-src
yarn
yarn run dev
```

Build the demo:

```
yarn run build
```
